/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;
import javax.swing.*;
import java.awt.*;


/**
 *
 * @author Sakhi Computer
 */
public class Test extends JWindow {

    /**
     * @param args the command line arguments
     */
    
        // TODO code application logic here

   Image splashScreen;
   ImageIcon imageIcon;
   public Test() {
      splashScreen = Toolkit.getDefaultToolkit().getImage("C:\\Users\\Sakhi Computer\\Desktop\\s.jpg");
      // Create ImageIcon from Image
      imageIcon = new ImageIcon(splashScreen);

      // Set JWindow size from image size
      setSize(imageIcon.getIconWidth(),imageIcon.getIconHeight());

      // Get current screen size
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

      // Get x coordinate on screen for make JWindow locate at center
      int x = (screenSize.width-getSize().width)/2;

      // Get y coordinate on screen for make JWindow locate at center
      int y = (screenSize.height-getSize().height)/2;

      // Set new location for JWindow
      setLocation(x,y);

      // Make JWindow visible
      setVisible(true);
   }
   // Paint image onto JWindow
   public void paint(Graphics g) {
      super.paint(g);
      g.drawImage(splashScreen, 0, 0, this);
   }
   
   public static void main(String[]args) {
      Test splash = new Test();
      try {
         // Make JWindow appear for 10 seconds before disappear
         Thread.sleep(1000);
         new New1().show();
         splash.dispose();
      } catch(Exception e) {
         e.printStackTrace();
      }
   }

    

    }
